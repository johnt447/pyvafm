
#include <Python.h>


int main(void) {
	
	
	
	
	
}


