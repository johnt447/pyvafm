#ifndef COREFLIPFLOP
#define COREFLIPFLOP


void DRFlipFlop( circuit *c );
void JKFlipFlop( circuit *c );
void  DFlipFlop( circuit *c );
void SRFlipFlop( circuit *c );

#endif
