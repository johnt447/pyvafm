#ifndef COREPY
#define COREPY

void PYUpdate( circuit* c );

#endif

