#ifndef CORELOGIC
#define CORELOGIC

void opAND( circuit *c );
void opNAND( circuit *c );
void opOR( circuit *c );
void opNOT( circuit *c );
void opXOR( circuit *c );
void opNOR( circuit *c );


#endif

