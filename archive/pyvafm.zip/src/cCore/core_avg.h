#ifndef COREAVG
#define COREAVG



void avg(circuit *c);
void avg_moving(circuit *c);


#endif
