#ifndef CORERSA
#define CORERSA

void RSA(circuit* c);

#endif

