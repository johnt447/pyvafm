#ifndef CORECONTROL
#define CORECONTROL

int Add_PI(int owner );
int Add_PID(int owner );
void PIC( circuit *c );
void PIDC( circuit *c );

#endif
