#ifndef CORECOMPARISON
#define CORECOMPARISON

void GreaterOrEqual( circuit *c );
void LessOrEqual( circuit *c );
void Equal( circuit *c );



#endif
