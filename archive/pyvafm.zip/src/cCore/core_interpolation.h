#ifndef COREINTER
#define COREINTER

int Add_i3Dlin( int owner, int components);
void i3Dlin( circuit *c );

void i1Dlin_periodic(circuit* c);
void i1Dlin(circuit* c);

#endif
