#ifndef CORESIGNALS
#define CORESIGNALS

void waver( circuit *c );
int Add_waver( int owner );

int Add_square( int owner );
void square(circuit *c);

#endif
