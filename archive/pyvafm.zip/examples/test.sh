cd..
ls
