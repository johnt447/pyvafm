from vafmbase import ChannelType
from vafmcircuits import Machine

import vafmcircuits